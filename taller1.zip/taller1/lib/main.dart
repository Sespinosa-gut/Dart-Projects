import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
 
        appBar: AppBar(
          title: Text(
            'PERFIL DE: KENNEN CORTES',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.black,
        ),
        
        backgroundColor: Color(0xFFFF69B4),
        
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 15),

              Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.black, width: 3),
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/duele.jpg',
                    fit: BoxFit.cover,
                    width: 140,
                    height: 140,
                  ),
                ),
              ),
              
              SizedBox(height: 12),
              
              Text(
                'Kennen Cortes',
                style: TextStyle(fontSize: 22, color: Colors.white),
              ),
              Text(
                'Aprendiz SENA',
                style: TextStyle(color: Colors.white70),
              ),
              
              SizedBox(height: 18),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.facebook, size: 35, color: Colors.white),
                  SizedBox(width: 15),
                  Icon(Icons.mail, size: 35, color: Colors.red),
                  SizedBox(width: 15),
                  Icon(Icons.chat, size: 35, color: Colors.green),
                ],
              ),
              
              SizedBox(height: 18),

              Container(
                height: 180,
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: ListView(
                  children: [
                    ElevatedButton(
                      onPressed: () { print('Programacion'); },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
                      child: Text('Programacion', style: TextStyle(color: Colors.white)),
                    ),
                    SizedBox(height: 6),
                    ElevatedButton(
                      onPressed: () { print('Diseño'); },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
                      child: Text('Diseño', style: TextStyle(color: Colors.white)),
                    ),
                    SizedBox(height: 6),
                    ElevatedButton(
                      onPressed: () { print('Base de datos'); },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
                      child: Text('Base de datos', style: TextStyle(color: Colors.white)),
                    ),
                    SizedBox(height: 6),
                    ElevatedButton(
                      onPressed: () { print('Redes'); },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
                      child: Text('Redes', style: TextStyle(color: Colors.white)),
                    ),
                    SizedBox(height: 6),
                    ElevatedButton(
                      onPressed: () { print('Soporte'); },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
                      child: Text('Soporte', style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ),
              
              SizedBox(height: 15),

              Container(
                height: 250,
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: GridView.count(
                  crossAxisCount: 3,
                  children: [
                    Container(
                      margin: EdgeInsets.all(4),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset('assets/image.png', fit: BoxFit.cover),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(4),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset('assets/image1.png', fit: BoxFit.cover),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(4),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset('assets/logoss.png', fit: BoxFit.cover),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(4),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset('assets/image.png', fit: BoxFit.cover),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(4),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset('assets/image1.png', fit: BoxFit.cover),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(4),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset('assets/logoss.png', fit: BoxFit.cover),
                      ),
                    ),
                   ],
                ),
              ),

              Padding(
                padding: EdgeInsets.all(10),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text('v1.0', style: TextStyle(color: Colors.white)),
                ),
              ),
              
            ],
          ),
        ),
      ),
    );
  }
}
